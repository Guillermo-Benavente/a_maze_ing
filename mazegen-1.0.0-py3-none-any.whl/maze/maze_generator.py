from collections.abc import Callable
from typing import TextIO, Any
from sys import stdout, stderr
from collections import deque
from .config import MazeConfig
from .enums import CellType, LimitWallType
from .cell import Cell


class MazeGenerator():
    """
    Handles the creation, grid management,
    outer boundary placement, and file rendering of the maze.
    """
    maze: list[list[Cell]]
    data: MazeConfig
    solution: str | None
    algoritm: dict[str, Callable[..., Any]] | None
    special_cells: list[tuple[int, int, Cell]]

    def __init__(self, data: MazeConfig) -> None:
        """
        Sets up the grid, builds paths/boundaries,
        executes the mining lifecycle, and outputs the result document.

        Args:
            data (Data): The configuration data object containing
                dimensions and properties.
        """
        from .maze_miner import MazeMiner
        self.maze = [
            [
                Cell((width, height))
                for width in range(data.WIDTH)
            ]
            for height in range(data.HEIGHT)
        ]
        self.data = data
        self.special_cells = []
        self._create_maze()
        MazeMiner(self)
        if not self.data.VISUAL3D and self.data.ALGORITM is not None:
            self.algoritm = self.data.ALGORITM(self.maze)
            deque(self.algoritm["algoritm"](), maxlen=0)
            if len(self.algoritm["list"]()) != 0:
                self.solution = self.algoritm["sorter"]()
            else:
                self.solution = None
        else:
            self.algoritm = None
            self.solution = ""
        self._generatedoc()

    def _generatedoc(self) -> None:
        """
        Writes the final hexadecimal layout,
        entry/exit vectors, and path solution to the designated output file.
        """
        with open(self.data.OUTPUT_FILE, "w") as fd:
            for i in self.maze:
                for j in i:
                    print(j.hexadecimal, end="", file=fd)
                print("", file=fd)
            entry = f"{self.data.ENTRY}".strip('(').strip(')')
            exits = f"{self.data.EXIT}".strip('(').strip(')')
            print(f"\n{entry.replace(' ', '')}", file=fd)
            print(exits.replace(' ', ''), file=fd)
            print(self.solution, file=fd)

    def _create_maze(self) -> None:
        """
        Validates grid dimensions and coordinates the layout
        setup for entries, exits, limits, and patterns.
        """
        start_height: int = 0
        start_width: int = 0
        if self.data.WIDTH <= 7 and self.data.HEIGHT <= 5:
            print("Maze too small to draw '42' pattern.", file=stderr)
        elif self.data.WIDTH <= 7 or self.data.HEIGHT <= 5:
            if self.data.WIDTH <= 7:
                print(
                    "Width maze too small to draw '42' pattern.",
                    file=stderr
                )
            if self.data.HEIGHT <= 5:
                print(
                    "Height maze too small to draw '42' pattern.",
                    file=stderr
                )
        else:
            if self.data.WIDTH != 8:
                start_width = (self.data.WIDTH // 2) - 3
            if self.data.HEIGHT != 6:
                start_height = (self.data.HEIGHT // 2) - 2
        self._search_inout()
        self._create_limits()
        self._create_forty_two(start_height, start_width)

    def _create_forty_two(
        self,
        start_height: int,
        start_width: int
    ) -> None:
        """
        Flags specific coordinates to draw a '42' restriction
        layout while ensuring no overlap with start/end zones.

        Args:
            start_height (int): Row index to start
                rendering the '42' pattern.
            start_width (int): Column index to start
                rendering the '42' pattern.

        Raises:
            Exception: If the pattern zone overlaps with
                the entry or exit cells.
        """
        if self.data.WIDTH <= 7 or self.data.HEIGHT <= 5:
            return
        for y in range(5):
            for x in range(7):
                height = start_height + y
                width = start_width + x
                cell = self.maze[height][width]
                if (
                    x != 3 and
                    not (y == 0 and (x == 1 or x == 2)) and
                    not (y == 1 and 1 <= x <= 5) and
                    not (y == 3 and x in [0, 1, 5, 6]) and
                    not (y == 4 and (x == 0 or x == 1))
                ):
                    if (
                        CellType.ENTRY in cell.cell_type or
                        CellType.EXIT in cell.cell_type
                    ):
                        raise Exception(
                            (
                                "Entry or exit coordinates"
                                " collide with the '42' pattern zone."
                            )
                        )
                    cell.cell_type.append(CellType.FORTY_TWO)
                    self.special_cells.append((width, height, cell))

    def _create_limits(self) -> None:
        """
        Iterates through outer rows and columns to mark boundary
        structures and map their localized wall directions.
        """
        height: int = self.data.HEIGHT
        width: int = self.data.WIDTH

        for x in range(width):
            north: Cell = self.maze[0][x]
            south: Cell = self.maze[height - 1][x]
            north.cell_type.append(CellType.LIMIT)
            north.limit_wall_type.append(LimitWallType.NORTH)
            south.cell_type.append(CellType.LIMIT)
            south.limit_wall_type.append(LimitWallType.SOUTH)
        for y in range(height):
            west: Cell = self.maze[y][0]
            east: Cell = self.maze[y][width - 1]
            west.cell_type.append(CellType.LIMIT)
            west.limit_wall_type.append(LimitWallType.WEST)
            east.cell_type.append(CellType.LIMIT)
            east.limit_wall_type.append(LimitWallType.EAST)

    def _search_inout(self) -> None:
        """
        Locates the starting entry and ending exit coordinates on
        the grid, modifying their types accordingly.
        """
        x_entry: int
        y_entry: int
        x_exit: int
        y_exit: int
        x_entry, y_entry = self.data.ENTRY
        x_exit, y_exit = self.data.EXIT
        entry_cell = self.maze[y_entry][x_entry]
        exit_cell = self.maze[y_exit][x_exit]
        entry_cell.cell_type.append(CellType.ENTRY)
        exit_cell.cell_type.append(CellType.EXIT)
        self.special_cells.append((x_entry, y_entry, entry_cell))
        self.special_cells.append((x_exit, y_exit, exit_cell))

    def view_maze(self) -> None:
        """
        Outputs a raw stream of the entire maze's hexadecimal
        representations directly to the standard console.
        """
        for height in range(self.data.HEIGHT):
            for width in range(self.data.WIDTH):
                print(self.maze[height][width].hexadecimal, end="")
            print()

    def view_maze_ascii(
        self,
        pos: tuple[int, int],
        file: TextIO = stdout
    ) -> None:
        """
        Renders a highly descriptive ASCII art representation of the
        maze structure, highlighting walls and checkpoints.

        Args:
            pos (tuple[int, int]): Current player position (x, y)
                to render as '_P_'.
            file (TextIO, optional): IO stream stream where the art will
                be printed. Defaults to stdout.
        """
        WALL_H: str = "---"
        WALL_V: str = "|"
        CORNER: str = "+"
        EMPTY_H: str = "   "
        EMPTY_V: str = " "
        x, y = pos
        for height in range(self.data.HEIGHT):
            line_top = ""
            line_mid = ""
            for width in range(self.data.WIDTH):
                cell = self.maze[height][width]
                n = bool(cell.binary & 1)
                w = bool(cell.binary & 8)
                if CellType.FORTY_TWO in cell.cell_type:
                    line_top += "####"
                    line_mid += "####"
                else:
                    line_top += CORNER + (WALL_H if n else EMPTY_H)
                    char_w = WALL_V if w else EMPTY_V
                    if CellType.ENTRY in cell.cell_type:
                        content = "[_]"
                    elif CellType.EXIT in cell.cell_type:
                        content = "_H_"
                    elif x == width and y == height:
                        content = "_P_"
                    else:
                        content = "   "
                    line_mid += char_w + content
            last_cell = self.maze[height][-1]
            e = bool(last_cell.binary & 2)
            line_top += CORNER
            line_mid += (WALL_V if e else EMPTY_V)
            print(line_top, file=file)
            print(line_mid, file=file)
        last_row_line = ""
        for width in range(self.data.WIDTH):
            cell = self.maze[self.data.HEIGHT - 1][width]
            s = bool(cell.binary & 4)
            last_row_line += CORNER + (WALL_H if s else EMPTY_H)
        print(last_row_line + CORNER, file=file)
